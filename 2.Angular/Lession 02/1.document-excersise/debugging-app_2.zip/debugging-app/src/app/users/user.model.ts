export class User {
  id: number = 0;
  first: string = '';
  last: string = '';
}
