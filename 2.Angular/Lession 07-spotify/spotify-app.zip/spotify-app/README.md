# SpotifyApp

# 1. Chuc nang

Tim kiem nghe si su dung Spotify API, se ra duoc 1 danh sach.
Nguoi dung click vao tung nghe se 1 thi ra thong tin detail, top track cua nghe si

# 2. Phan tich cau truc App

3 phan chinh:

1. Input
2. Search Result
3. Detail

# 3. Lam layout (HTML CSS)

Done

# 4. Ket noi Componetn voi HTMLT

## 4.1 Input

Done
