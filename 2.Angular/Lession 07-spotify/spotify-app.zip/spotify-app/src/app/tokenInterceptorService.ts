import { Injectable } from '@angular/core';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpEvent
} from '@angular/common/http';
import { Observable } from 'rxjs';

export const API_TOKEN = `BQCkOZng415vxG_sHgmbFDWKtlExVHta16TiFzhd4kJr-rEBRr9tVRaUufD_iyrHyEV6yvsYZCGf96cMwSEM8uREx0FJSEFMAMcNQWTcHOxhVoEI-u-z66CVDRu-3ceuGguuq5Kw0hlkEA`;

@Injectable({
  providedIn: 'root'
})
export class TokenInterceptorService implements HttpInterceptor {
  constructor() {}

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const tokenizedReq = req.clone({
      setHeaders: {
        // tslint:disable-next-line:max-line-length
        Authorization: `Authorization: Bearer ${API_TOKEN}`
      }
    });
    return next.handle(tokenizedReq);
  }
}
